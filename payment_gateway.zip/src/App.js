import React from 'react';
import './App.css';


import CreditCardForm from './Components/Form'

class App extends React.Component {


  render() {

    return (
      <div>
        <CreditCardForm/>
      </div>
    )
  }

}

export default App;
