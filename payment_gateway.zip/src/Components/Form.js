import React, { useEffect, useState } from 'react';
import { Button, Form, Grid, Header, Image, Message, Segment, Label, Dropdown } from 'semantic-ui-react'
import Cleave from 'cleave.js/react'
import creditCardType from 'credit-card-type'
import { validate } from '@babel/types';

const CreditCardForm = props => {

    const [state, setState] = useState({
        name: '',
        cardNo: '',
        expDate: '',
        ccv: '',
        cardType: '',
        cardTypeImg: '',
        cardTypeccv: '',
        isCCValid: true,
        codeLength: 0
    });

    const [error, setError] = useState({
        name: '',
        cardNo: '',
        ccv: ''
    })

    useEffect(() => {
        setState({
            name: '',
            cardNo: '',
            expDate: '',
            ccv: '',
            cardType: '',
            cardTypeImg: '',
            cardTypeccv: '',
            isCCValid: true,
            codeLength: 0
        })

        setError({
            name: '',
            cardNo: '',
            ccv: ''
        })
    }, [])

    const handleChange = event => {
        console.log('handle change ' + event.target.name + ' ' + event.target.value);
        setState({
            ...state,
            [event.target.name]: event.target.value
        });
        // validate(event.target.name, event.target.value);
        console.log('value ' + state.name)
        console.log('value ' + state.cardNo);
        console.log('value ' + state.ccv);
    }

    const validate = (name, value) => {
        console.log('name ' + name + ' value ' + value);
        switch(name){
            case 'name':
            if(value.length < 4){
                setError({
                    ...error,
                    ['name']: 'Name should greater than 4 charactors'
                })
            }else{
                setError({
                    ...error,
                    ['name']: ''
                })
            }

            break;
            case 'cardNo':
                if(value.length < 9){
                    setError({
                        ...error,
                        ['cardNo']: 'Charactor length should greater than 9 chars'
                    })
                }else{
                    setError({
                        ...error,
                        ['cardNo']: ''
                    })
                }
            break;
            case 'ccv':
                if(value.length < 9){
                    setError({
                        ...error,
                        ['ccv']: 'validation message of ccv'
                    })
                }else{
                    setError({
                        ...error,
                        ['ccv']: ''
                    })
                }
            break;
        }

    }

    const onChange = event => {

        console.log(event.target.name + ' ' + event.target.value);

        let cards = creditCardType(event.target.value);
        console.log(cards)
        if (cards.length > 0) {

            setState({

                cardType: cards[0].type,
                cardTypeccv: cards[0].code["name"],
                codeLength: cards[0].code['size'],
                cardTypeImg: './images/cards/' + cards[0].type + '.png'
            })

        } else {

            setState({

                cardType: '',
                cardTypeccv: '',
                cardTypeImg: '',
                ccv: '',
                codeLength: 0
            })


        }
        console.log('length ' + state.codeLength)

        if (event.target.value.length == 0) {

            setState({

                cardType: '',
                cardTypeccv: '',
                cardTypeImg: '',
                ccv: '',
                codeLength: 0
            })
        }


    }

    const handleSubmit = event => {
        alert('A name was submitted: ' + state.CardNo + "----" + state.Name);
        event.preventDefault();
    }

    const onSubmit = () => {
        console.log('came here');
        ['name', 'cardNo', 'ccv'].forEach(key => validate(key, state[key]));
    }
    return (
        <Grid textAlign='center' style={{ height: '100vh' }} verticalAlign='middle'>
            <Grid.Column style={{ maxWidth: 450 }}>
                <Header as='h2' color='teal' textAlign='center'>
                    Payment Gateway
            </Header>
                <Form size='large' onSubmit={handleSubmit}>
                    <Segment stacked>
                        <Grid >
                            <Grid.Row columns={1} centered>
                                <Grid.Column >
                                    <Form.Field error={error['name'].length > 0}>
                                        {/* <label style={{ float: 'left' }} error>Name On Card</label> */}
                                        <Form.Input
                                            fluid icon='user'
                                            label='Name On Card'
                                            iconPosition='left'
                                            placeholder='Card Holders Name '
                                            value={state.Name}
                                            onChange={handleChange}
                                            name='name'
                                            type={'text'}
                                        />
                                        <Message
                                            error={error['name'].length > 0}
                                            header='Header Validation'
                                            content={error['name']}
                                            />
                                    </Form.Field>
                                </Grid.Column>
                            </Grid.Row>
                            <Grid.Row columns={2} >
                                <Grid.Column computer={13} mobile={12} tablet={13}>
                                    <Form.Field error={error['cardNo'].length > 0}>
                                        <label style={{ float: 'left' }}>Card Number</label>
                                        <Cleave placeholder="Enter your credit card number"

                                            options={{

                                                creditCard: true,
                                                delimiter: '-',
                                                width: 6
                                            }}
                                            onChange={onChange} />
                                       <Message
                                            error={error['cardNo'].length > 0}
                                            header='credit card header validation'
                                            content={error['cardNo']}
                                            />
                                    </Form.Field>
                                </Grid.Column>
                                <Grid.Column
                                    computer={3} mobile={4} tablet={3}
                                    verticalAlign={'bottom'}
                                >
                                    <Image src={state.cardTypeImg} size='tiny' style={{ width: '60px', height: '36px', float: 'right' }} />

                                </Grid.Column>
                            </Grid.Row>
                            <Grid.Row columns={2} centered>
                                <Grid.Column width={6}>

                                    <Form.Field>
                                        <label style={{ float: 'left' }}>Expire Date</label>
                                        <Cleave placeholder="MM/YY"
                                            options={{
                                                date: true,
                                                dateMin: '19-01',
                                                dateMax: '28-12',
                                                datePattern: ['m', 'y']
                                            }}  
                                        />
                                    </Form.Field>
                                </Grid.Column>
                                <Grid.Column width={10}>
                                </Grid.Column>
                            </Grid.Row>
                            <Grid.Row columns={1}>
                                <Grid.Column>
                                    <Form.Field error={error['ccv'].length > 0}>
                                        <label style={{ float: 'left' }}>Code : {state.cardTypeccv}</label>
                                        {console.log('size ' + state.codeLength)}
                                        <Form.Input fluid width={4} maxLength={state.codeLength} onChange={handleChange} value={state.ccv} name='ccv' disabled={state.codeLength==0}/>
                                        <Message
                                            error={error['ccv'].length > 0}
                                            header='ccv validation header'
                                            content={error['ccv']}
                                            />
                                    </Form.Field>
                                </Grid.Column>
                            </Grid.Row>
                            <Grid.Row columns={1}>
                                <Grid.Column>
                                    <Button color='teal' fluid size='large' type="submit" onClick={onSubmit}>
                                        Process Payment
                                    </Button>
                                </Grid.Column>
                            </Grid.Row>
                        </Grid>
                    </Segment>
                </Form>
            </Grid.Column>
        </Grid>
    )
}

export default CreditCardForm;